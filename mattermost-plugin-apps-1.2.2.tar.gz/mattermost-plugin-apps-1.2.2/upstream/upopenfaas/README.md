#### Setup
- Install faas-cli: https://docs.openfaas.com/cli/install/
- Install faasd with multipass https://github.com/openfaas/faasd/blob/master/docs/MULTIPASS.md
