// goapp is an EXPERIMENTAL package to make simple Mattermost apps written in
// go.
package goapp
