// Copyright (c) 2019-present Mattermost, Inc. All Rights Reserved.
// See License for license information.

package apps

const (
	PropAppBindings = "app_bindings"
)
