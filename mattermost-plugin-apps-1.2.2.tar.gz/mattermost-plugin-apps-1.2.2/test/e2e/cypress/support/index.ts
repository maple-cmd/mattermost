// Copyright (c) 2015-present Mattermost, Inc. All Rights Reserved.
// See LICENSE.txt for license information.

// ***********************************************************
// Read more at: https://on.cypress.io/configuration
// ***********************************************************

import 'mattermost-webapp/e2e/cypress/tests/support';

before(() => {
    localStorage.setItem('__landingPageSeen__', String(true));
});
